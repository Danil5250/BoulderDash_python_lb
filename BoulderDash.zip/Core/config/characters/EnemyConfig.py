class EnemyConfig:
    ENEMY_MOVE_DELAY = 2  # Enemy moves every 3 ticks
    ENEMY_SIGN = 'E'
    ENEMY_COLOR = (255, 0, 0)
    LIVES = 1
    DAMAGE_TO_PLAYER = 1