class SandConfig:
    SAND_SIGN = '.'
    #SAND_COLOR = Fore.YELLOW
    SAND_COLOR = (194, 178, 128)
    CAN_STONE_MOVED_AT_SAND = True
    SAND_TO_STRING = "sand"