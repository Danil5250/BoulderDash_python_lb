class DiamondConfig:
    DIAMOND_SIGN = 'D'
    #DIAMOND_COLOR = Fore.BLUE
    DIAMOND_COLOR = (0, 255, 255)
    COUNT_ADD_SCORE_TO_PLAYER = 1
    DIAMOND_TO_STRING = "diamond"