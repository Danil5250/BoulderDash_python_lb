class StoneConfig:
    STONE_SIGN = 'o'
    #STONE_COLOR = Fore.WHITE (colorama)
    STONE_COLOR = (100, 100, 100)
    CAN_PLAYER_PASS = False
    STONE_DAMAGE_PLAYER = 1
    STONE_TO_STRING = "stone"
    FALL_DELAY = 10
    FALL_TIMER = 0
    IS_FALLING = False