class GameConfig:
    FIELD_WIDTH = 20
    FIELD_HEIGHT = 15
    STONE_DENSITY = 0.2
    COUNT_LIVES = 3