class DisplayConfig:
    WIDTH, HEIGHT = 800, 600
    UI_PANEL_HEIGHT = 80